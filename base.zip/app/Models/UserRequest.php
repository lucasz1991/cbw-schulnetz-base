<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Casts\AsArrayObject;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\MorphMany;

class UserRequest extends Model
{
    use HasFactory;

    /**
     * -------------------------------------------------------------------------
     *  Typen und Status (optionale Konstanten)
     * -------------------------------------------------------------------------
     */
    public const TYPE_ABSENCE         = 'absence';
    public const TYPE_MAKEUP          = 'makeup';
    public const TYPE_EXTERNAL_MAKEUP = 'external_makeup';
    public const TYPE_GENERAL         = 'general';

    public const STATUS_PENDING   = 'pending';
    public const STATUS_APPROVED  = 'approved';
    public const STATUS_REJECTED  = 'rejected';
    public const STATUS_CANCELED  = 'canceled';
    public const STATUS_IN_REVIEW = 'in_review';

    /**
     * -------------------------------------------------------------------------
     *  Massenweise befüllbare Felder
     * -------------------------------------------------------------------------
     */
    protected $fillable = [
        'user_id',
        'type',
        'class_code',
        'institute',
        'participant_no',
        'title',
        'message',
        'date_from',
        'date_to',
        'original_exam_date',
        'scheduled_at',
        'module_code',
        'instructor_name',
        'full_day',
        'time_arrived_late',
        'time_left_early',
        'reason',
        'reason_item',
        'with_attest',
        'fee_cents',
        'exam_modality',
        'certification_key',
        'certification_label',
        'class_label',
        'email_priv',
        'attachment_path',
        'status',
        'submitted_at',
        'decided_at',
        'admin_comment',
        'data',
    ];

    /**
     * -------------------------------------------------------------------------
     *  Casts
     * -------------------------------------------------------------------------
     */
    protected $casts = [
        'date_from'          => 'date',
        'date_to'            => 'date',
        'original_exam_date' => 'date',
        'scheduled_at'       => 'datetime',
        'submitted_at'       => 'datetime',
        'decided_at'         => 'datetime',
        'full_day'           => 'boolean',
        'with_attest'        => 'boolean',
        'fee_cents'          => 'integer',
        'data'               => AsArrayObject::class,
    ];

    /**
     * -------------------------------------------------------------------------
     *  Beziehungen
     * -------------------------------------------------------------------------
     */

    /** Antragsteller */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /** Optionale Dateien (polymorph, standardisiert im Projekt) */
    public function files(): MorphMany
    {
        return $this->morphMany(\App\Models\File::class, 'fileable');
    }

    /**
     * -------------------------------------------------------------------------
     *  Accessors & Helper
     * -------------------------------------------------------------------------
     */

    /** Formatierte Gebühr (z. B. 20,00 €) */
    public function getFeeFormattedAttribute(): ?string
    {
        return is_null($this->fee_cents)
            ? null
            : number_format($this->fee_cents / 100, 2, ',', '.') . ' €';
    }

    /** Anzeige für „mit/ohne Attest“ */
    public function getWithAttestLabelAttribute(): string
    {
        return $this->with_attest ? 'mit Attest' : 'ohne Attest';
    }

    /** Kurze Statusbeschreibung */
    public function getStatusLabelAttribute(): string
    {
        return match ($this->status) {
            self::STATUS_APPROVED  => 'Genehmigt',
            self::STATUS_REJECTED  => 'Abgelehnt',
            self::STATUS_CANCELED  => 'Storniert',
            self::STATUS_IN_REVIEW => 'In Prüfung',
            default                => 'Eingereicht',
        };
    }

    /**
     * -------------------------------------------------------------------------
     *  Scopes / Query Helpers
     * -------------------------------------------------------------------------
     */

    public function scopeType($query, string $type)
    {
        return $query->where('type', $type);
    }

    public function scopeStatus($query, string $status)
    {
        return $query->where('status', $status);
    }

    public function scopeRecent($query)
    {
        return $query->orderByDesc('submitted_at');
    }

    /**
     * -------------------------------------------------------------------------
     *  Business-Methoden
     * -------------------------------------------------------------------------
     */

    public function approve(?string $adminComment = null): void
    {
        $this->forceFill([
            'status' => self::STATUS_APPROVED,
            'decided_at' => now(),
            'admin_comment' => $adminComment,
        ])->save();
    }

    public function reject(?string $adminComment = null): void
    {
        $this->forceFill([
            'status' => self::STATUS_REJECTED,
            'decided_at' => now(),
            'admin_comment' => $adminComment,
        ])->save();
    }

    public function cancel(?string $adminComment = null): void
    {
        $this->forceFill([
            'status' => self::STATUS_CANCELED,
            'decided_at' => now(),
            'admin_comment' => $adminComment,
        ])->save();
    }

    
}
