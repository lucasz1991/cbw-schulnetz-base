<!DOCTYPE html>
<html>
<head>
    <title>Test E-Mail</title>
</head>
<body>
    <h1>Willkommen!</h1>
    <p>Dies ist eine Test-E-Mail. Wenn du dies sehen kannst, ist die Mail-Konfiguration korrekt.</p>
</body>
</html>