<img 
    class="w-full max-w-32 {{ $class ?? '' }}" 
    src="{{ asset('/site-images/logo.png') }}" 
    alt="Logo">