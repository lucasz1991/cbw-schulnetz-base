<img 
    class="w-full {{ $class ?? '' }}" 
    src="{{ asset('/site-images/logo.png') }}" 
    alt="Application Logo">