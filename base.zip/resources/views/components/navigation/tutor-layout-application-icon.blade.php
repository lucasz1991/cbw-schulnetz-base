<img 
    class="{{ $class ?? '' }}" 
    src="{{ asset('/site-images/icon.png') }}" 
    alt="Application Icon">