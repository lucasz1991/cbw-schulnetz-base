<img 
    class="max-h-18 {{ $class ?? '' }}" 
    src="{{ asset('/site-images/logo-xs.png') }}" 
    alt="Logo">