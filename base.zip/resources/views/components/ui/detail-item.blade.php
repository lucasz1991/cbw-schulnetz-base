@props(['label','value'=>'—'])
<div>
  <div class="text-xs text-gray-500">{{ $label }}</div>
  <div class="text-sm text-gray-900">{{ $value }}</div>
</div>
