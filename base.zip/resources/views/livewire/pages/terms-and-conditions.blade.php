<div class=" antialiased" wire:loading.class="cursor-wait"  x-data="{ selectedTab: 'userAgb' }">

    <div class="">
        <div class="">




        </div>
    </div>
</div>