<div class=" antialiased" wire:loading.class="cursor-wait">

</div>

