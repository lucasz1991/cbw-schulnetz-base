<div wire:loading.class="cursor-wait" class=" bg-gray-100">

</div>
